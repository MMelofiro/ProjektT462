
package projekt;

public class Spiel01Wand {
	Input input = new Input();

	public Spiel01Wand() {
	}

	public void wand(Player player) {
		this.input.next();
		player.recover();
		System.out.println("Wand erklimmen");
		System.out.println("Das Spiel besteht darin, auf die andere Seite eines Raums zu kommen, der durch eine 5 Meter hohe Wand, die auf der weichen Erde sich befindet, geteilt ist. ");
		this.input.next();
		System.out.println("Sie schauen sich um und bemerken zwei Details.");
		System.out.println("Die Decke des Raums ist hoch genug, um über die Wand zu springen. Es gibt noch im Raum: ein Seil, ein 3 Meter langer Bambus, und eine Schaufel.");
		System.out.print("Sie besprechen mit " + player.getMitspieler() + ", wie Sie Herausforderungen meistern können,");
		System.out.println("und" + player.getMitspieler() + "schlägt die Verwendung von Bambus vor");
		this.input.next();

		int nummer;
		for(nummer = this.input.scannerInt("1. Seil\n2. Bambus\n3. Schaufel", 3); nummer != 3; nummer = this.input.scannerInt("1. Seil\n2. Bambus\n3. Schaufel", 3)) {
			System.out.println("Sie sind gefallen");
			this.input.fixNext();
			this.input.next();
			player.setHp(player.getHp() - 10);
			player.setSt(player.getSt() - 10);
			player.statusZeigen();
			this.input.next();
			if (player.getHp() <= 0 || player.getSt() <= 0) {
				this.wand(player);
				break;
			}

			System.out.println("Noch einmal versuchen");
		}

		if (nummer == 3) {
			player.setSt(player.getSt() - 10);
			if (player.getHp() > 0 && player.getSt() > 0) {
				System.out.println("Erfolgreich! Sie sind an der Tür, die zum nächsten Spiel führt, angekommen.");
				player.setSt(player.getSt() + 5);
				player.setHp(player.getHp() + 5);
			} else {
				this.wand(player);
			}
		}

	}
}
