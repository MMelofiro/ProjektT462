//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package projekt;

public class Spiel02Schwimm {
    Input input = new Input();

    public Spiel02Schwimm() {
    }

    public void schwimm(Player player) {
        player.recover();
        player.statusZeigen();
        this.input.next();
        System.out.println("Du gehst durch einen dunklen Flur. Ein Geruch nach Chlor wird immer stärker.");
        this.input.next();
        System.out.println("Die Wachen öffnen die Tür.");
        this.input.next();
        System.out.println("Du siehst ein großes Schwimmbad. Der Raum hat himmelblaue Wände und einen weiß gekachelten Boden.");
        this.input.next();
        System.out.println("Am Ende des Raumes befindet sich eine Tür, zu der du leicht gehen könntest.");
        this.input.next();
        System.out.println("Der Geruch nach Chlor ist verschwunden, du hast dich daran gewöhnt.");
        this.input.next();
        System.out.println("Man hört das Geräusch des Mikrofons, das aktiviert wird. Es ist der Ansager. Er wird die Anweisungen geben.");
        this.input.next();
        System.out.println("\"Herzlichen Glückwunsch zum Bestehen der ersten Herausforderung.\nDie nächste Herausforderung heißt \"Das Schwimmbad\".");
        this.input.next();
        System.out.println("Wie Sie sehen können, befindet sich am Ende des Raumes eine verschlossene Tür. Um sie zu öffnen, müssen Sie den richtigen Schlüssel finden, der am Boden des Schwimmbads liegt.");
        this.input.next();
        System.out.println("Dazu haben Sie zwei Möglichkeiten. Tauchen Sie mit der Ausrüstung, die sich an jedem Ende des Schwimmbads befindet, oder drehen Sie das Ventil vor dem Schwimmbad.");
        this.input.next();
        System.out.println("Diese letzte Aktion kann nur einmal durchgeführt werden, und je nachdem, in welche Richtung Sie drehen, gibt es zwei verschiedene Ergebnisse.");
        this.input.next();
        System.out.println("Wenn Sie in die richtige Richtung drehen, wird das Wasser abgelassen und das Schwimmbad wird wasserfrei sein.");
        this.input.next();
        System.out.println("Wenn Sie in die falsche Richtung drehen, werden die Wasserleitungen geöffnet, was dazu führt, dass der gesamte Raum in wenigen Minuten unter Wasser steht.");
        this.input.next();
        System.out.println("Das sind alle Anweisungen. Das Spiel beginnt.\"");
        this.input.next();
        int choice = this.input.scannerInt("Was machen Sie?\n1. Sauerstoffballon\n2. Tauchermaske und Flossen\n3. Wasserventil", 3);
        int choice1aus = 0;
        int choice2aus = 0;

        label79:
        while(choice == 1) {
            System.out.println("Du versuchst zu tauchen. Nach einer Minute fällt es dir auf, dass du immer weniger Luft kriegst.");
            this.input.fixNext();
            this.input.next();
            System.out.println("Die Luftstoffballon ist jetzt lehr! Du tauchst aus dem Wasser auf, aber du bist fast erstickt.");
            System.out.println("Du verlierst HP und ST.");
            this.input.next();
            player.setHp(player.getHp() - 30);
            player.setSt(player.getSt() - 40);
            player.statusZeigen();
            choice = 0;
            if (player.getHp() > 0 && player.getSt() > 0) {
                System.out.println("\nNoch einmal versuchen");
                choice1aus = this.input.scannerInt("1. Sauerstoffballon\n2. Tauchermaske und Flossen\n3. Wasserventil", 3);

                while(true) {
                    if (choice1aus != 1) {
                        continue label79;
                    }

                    System.out.println("\nDu hast das schon benutzt.");
                    this.input.fixNext();
                    this.input.next();
                    choice1aus = this.input.scannerInt("1. Sauerstoffballon\n2. Tauchermaske und Flossen\n3. Wasserventil", 3);
                }
            }

            this.schwimm(player);
            break;
        }

        if (choice == 2 || choice1aus == 2) {
            System.out.println("Du ziehst die Tauchermaske und die Flossen an, und tauchst.");
            System.out.println("Du verlierst ST.");
            player.setSt(player.getSt() - 40);
            player.statusZeigen();
            this.input.fixNext();
            this.input.next();
            choice1aus = 0;
            if (player.getHp() > 0 && player.getSt() > 0) {
                System.out.println("\nNach einer Weile, du findest einen Schlüssel. Tauchst aus dem Wasser auf, und probierst mit dem Schlüssel. Die Tür öffnet sich nicht.\n\nWas machst du?");
                choice2aus = this.input.scannerInt("1. Wieder tauchen und suchen\n2. Wasserventil drehen", 2);
                if (choice2aus == 1) {
                    System.out.println("Du wirst wieder getaucht.");
                    System.out.println("Jetzt wirst du müde.");
                    this.input.next();
                    player.setSt(player.getSt() - 40);
                    player.statusZeigen();
                    if (player.getHp() > 0 && player.getSt() > 0) {
                        System.out.println("Du hast einen anderen Schlüssel gefunden. Jetzt probierst du und die Tür öffnet sich.");
                        this.input.next();
                        System.out.println("Du hast es im nächsten Raum geschaft.");
                        System.out.println("Du erhälst +10 HP");
                        player.setHp(player.getHp() + 10);
                        player.statusZeigen();
                    } else {
                        this.schwimm(player);
                    }
                }
            } else {
                this.schwimm(player);
            }
        }

        if (choice == 3 || choice1aus == 3 || choice2aus == 2) {
            System.out.println("Das Wasserventil kann nur ein Mal gedreht werden. Du musst richtig entscheiden.\nIn eine Richtung wird das Wasser abgelassen; in die andere wird der gesamte Raum schnell überflutet.");
            this.input.fixNext();
            this.input.next();
            choice2aus = this.input.scannerInt("\nWas Entscheiden Sie?\n1. Nach links drehen\n2. Nach rechts drehen", 2);
            if (choice2aus == 2) {
                System.out.println("Das Wasserventil ist schwer zu drehen, aber sie drehen es nach rechts.");
                player.setSt(player.getSt() - 10);
                player.statusZeigen();
                if (player.getHp() > 0 && player.getSt() > 0) {
                    System.out.println("\nFünf Sekunden sind vergangen und sie hören ein Geräusch, das immer lauter wird.");
                    this.input.next();
                    System.out.println("\nMit dem Blick auf das Schwimmbad fixiert, merkst du, dass der Wasserstand abnimmt.");
                    this.input.next();
                    System.out.println("Die Wasser ist komplett abgelassen, und ihr findet den Schlüssel.");
                    this.input.next();
                    System.out.println("Sie haben es zu dem nächsten Raum geschafft!");
                    this.input.next();
                    player.setHp(player.getHp() + 10);
                    player.statusZeigen();
                    this.input.next();
                } else {
                    this.schwimm(player);
                }
            }

            if (choice2aus == 1) {
                System.out.println("Das Wasserventil ist schwer zu drehen, aber Sie drehen es nach links.\nDu verlierst ST.");
                this.input.fixNext();
                this.input.next();
                player.setSt(player.getSt() - 10);
                player.statusZeigen();
                if (player.getHp() > 0 && player.getSt() > 0) {
                    System.out.println("\nFünf Sekunden sind vergangen und sie hören nichts.");
                    this.input.next();
                    System.out.println("\nMit dem Blick auf das Schwimmbad fixiert, merkst du, dass der Wasserstand zunimmt.");
                    this.input.next();
                    System.out.println("Alle sind sofort auf der Suche nach dem Schlüssel.");
                    this.input.next();
                    System.out.println("Du suchst nach der Tauchermaske aber du findest es nicht, trotzdem tauchst du in das Wasser ein.\nDu verlierst ST.");
                    this.input.next();
                    player.setHp(player.getHp() - 20);
                    player.statusZeigen();
                    this.statusCheck(player);
                    this.input.next();
                    System.out.println("Du hast einen Schlüssel gefunden, aber du warst so lang im Wasser, dass du bist fast erstickt.\nDu verlierst HP.");
                    this.input.next();
                    player.setHp(player.getHp() - 30);
                    player.statusZeigen();
                    this.statusCheck(player);
                    this.input.next();
                    System.out.println("Der Schlüssel dreht aber die Tür öffnet sich nicht. Du Kriegst Luft und tauchst wieder ein.");
                    this.input.next();
                    System.out.println("Das Wasser geht immer höher und der Druck wird schwerer.\nDu wirst müde.");
                    this.input.next();
                    player.setSt(player.getSt() - 50);
                    player.statusZeigen();
                    this.statusCheck(player);
                    this.input.next();
                    System.out.println("Du hast einen anderen Schlüssel gefunden. Du schwimmst so schnell wie du kannst nach oben, und versuchst nochmal.");
                    this.input.next();
                    System.out.println("Die Tür hat sich geöffnet!\nDu bist im nächstem Raum erlaubt.");
                    this.input.next();
                    player.setHp(player.getHp() + 10);
                    player.statusZeigen();
                    this.input.next();
                } else {
                    this.schwimm(player);
                }
            }
        }

    }

    public void statusCheck(Player player) {
        if (player.getHp() < 1 || player.getSt() < 1) {
            this.schwimm(player);
        }

    }
}
