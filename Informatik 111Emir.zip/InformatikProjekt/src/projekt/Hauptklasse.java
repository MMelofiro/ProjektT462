//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package projekt;

public class Hauptklasse {
	public Hauptklasse() {
	}

	public static void main(String[] args) {
		Player player = new Player();
		Einfuehrung einfuehrung = new Einfuehrung();
		CharacterSelection charak = new CharacterSelection();
		SwierigkeitsCharachter schwierig = new SwierigkeitsCharachter();
		Spiel01Wand spiel01 = new Spiel01Wand();
		Spiel02Schwimm spiel02 = new Spiel02Schwimm();
		PolareRennen03 spiel03= new PolareRennen03(); // object spiel03 von der Klasse PolareRennen wird erzeugt Emir
		Spiel04Weg weg = new Spiel04Weg();
		Spiel05Seil spiel05 = new Spiel05Seil();
		PlatformSpringen06 spiel06= new PlatformSpringen06(); //  object spiel06 von der Klasse PlatformSpringen06 wird erzeugt Emir
		Schachspiel07 spiel07 = new Schachspiel07() ; //  object spiel07 von der Klasse Schachspiel wird erzeugt Emir
		char[][] schachbrett = new char[9][9]; // 2d Array der char enthält wird erzeugt und in der Klasse Schachspiel07 benutzt

		Ende ende = new Ende();
		einfuehrung.intro();
		charak.charakterAuswaehlen(player);
		schwierig.difficulty(player);
		player.save();

		spiel01.wand(player);
		player.save();

		spiel02.schwimm(player);
		player.save();
		player.save();
		weg.weg(player);
		player.save();

		spiel03.SpielInfo(); // Aufruf der Methode SpielInfo Emir
		spiel03.einzigeAktion(player); // Aufruf der Methode von einziger Aktion
		player.save(); // Die Werten von HP und ST werden behalten

		spiel05.Seilschwingen(player);
		player.save();
		player.save();
		player.save();

		spiel06.PlatformInfo(); // Aufruf der Methode PlatformInfo, alles unten gilt für object spiel06 Emir
		spiel06.ersteAktion(player); // Aufruf der ersten Aktion
		player.save(); // Die Werten von HP und ST werden behalten
		spiel06.mittlereAktion(player); // Aufruf der mittleren Aktion
		player.save(); // Die Werten von HP und ST werden behalten
		spiel06.letzzteAktion(player); // Aufruf der letzten Aktion
		player.save();
		if (player.getSchwer()) { // Wenn die Schwierigkeit Schwer true ist, wird Schachspiel dazu gespielt, ansonsten das Spiel beendet ist Emir

			spiel07.SchachspielInfo(); // Im Prinzip sind alle untere Zeile , die nicht "player.save();" Aufrufen der Methoden des Objectes spieol07
			player.save();
			spiel07.initializeChessboard(schachbrett);
			spiel07.SchachspielAktion(player, schachbrett);
			player.save();
			spiel07.SchachspielAktion2(player, schachbrett);
			spiel07.erneuerungSchachbrett(schachbrett);
			player.save();
		}

		if (player.getSchwer()) {
			player.save();
		}

		if (player.getGerettet()) {
			ende.ende2();
		} else {
			ende.ende1();
		}

	}
}

