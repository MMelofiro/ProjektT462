//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package projekt;

public class CharacterSelection {
	Input input = new Input();

	public CharacterSelection() {
	}

	public void charakterAuswaehlen(Player player) {
		System.out.println("Wählen Sie Ihren Charakter aus");
		player.charakter(this.input.scannerInt("1. Jason\n2. Allice", 2));
		System.out.println("Sie spielen als " + player.getSpieler() + ".");
		player.statusZeigen();
	}
}

