/**
 * 
 */
/**
 * 
 */
module InformatikProjekt {
}