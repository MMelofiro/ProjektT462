/**
 * 
 */
/**
 * 
 */
module InformatikProjekt {
    requires java.desktop;
}