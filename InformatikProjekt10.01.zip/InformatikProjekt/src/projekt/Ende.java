//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package projekt;

public class Ende {
    public Ende() {
    }

    public void ende1() {
        System.out.println("Glückwunsch! Sie haben alle Herausforderungen des Spiels gemeistert und die\nOrganisation, die das Spiel kontrolliert, gefunden!");
    }

    public void ende2() {
        System.out.println("Sie haben alle Herausforderungen gemeistert, aber die Person, die Sie gerettet\nhaben, ist ein Mitglied der Organisation. Sie wurden gefangen genommen und\ngetötet.");
    }
}
