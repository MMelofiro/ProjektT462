package projekt;

public class Einfuehrung {
	Input input = new Input();

	public Einfuehrung() {
	}

	public void intro() {
		System.out.println("Es ist 7 Uhr morgens");
		this.input.next();
		System.out.println("Der Wecker klingelt");
		this.input.next();
		System.out.println("1.Aufstehen\n2.Den Wecker schlummern lassen\n");
		this.input.scannerInt("Tippe \"1\" um aufzustehen\nTippe \"2\", um den Wecker zu schlummern", 2);
		System.out.println("Du kannst nicht den Wecker schlummern. Man muss arbeiten!");
		this.input.fixNext();
		this.input.next();
		System.out.println("Müde wachst du auf, um den Wecker auszuschalten.");
		this.input.next();
		System.out.println("Aus Versehen hast du den Wecker verschlummert. Es wäre eine Verschwendung, ihn aufzuschieben und keine zehn Minuten mehr zu schlafen.");
		this.input.next();
		System.out.println("Du entscheidest dich zu schlafen.");
		this.input.next();
		System.out.println("Du fängst an zu träumen...");
		this.input.next();
		System.out.println("...Du bist in einem Raum mit schwarz-weiß kariertem Boden...");
		this.input.next();
		System.out.println("...Eine Person liegt auf dem Boden...");
		this.input.next();
		System.out.println("...Du gehst auf sie zu, kannst du aber sie nicht erkennen...");
		this.input.next();
		System.out.println("...Als du näher kommst, beginnt der Raum zu überschwemmen...");
		this.input.next();
		System.out.println("...Du versuchst, die Person schneller zu erreichen... ....");
		this.input.next();
		System.out.println("...Eine bekannte Stimme ist aus einem Radio zu hören...");
		this.input.next();
		System.out.println("...Du kommst zu der Person, die dort liegt...");
		this.input.next();
		this.input.next();
		this.input.next();
		System.out.println("Dein Telefon klingelt...");
		this.input.next();
		System.out.println("Du stehst schnell auf, es ist deine Kollegin, Allice.");
		this.input.next();
		System.out.println("Allice: Jason, der Direktor vom Geheimdienst hat mich angerufen. Sie haben einen sehr großen Fall.");
		this.input.next();
		System.out.println("Jason: Häh?");
		this.input.next();
		System.out.println("Allice: Ich hoffe, du bist nicht gerade aufgestanden, sonst kommst du 15 Minuten zu spät ins Büro >:(");
		this.input.next();
		System.out.println("Du bist wieder eingeschlafen.");
		this.input.next();
		System.out.println("Und so fanden sich Jason und Allice, ehemalige Mitglieder des Geheimdienstes, wieder in ihrem letzten großen Fall, den sie übernehmen würden: \"Das Labyrinth\". ");
		this.input.next();
		System.out.println("Es handelte sich dabei um einen Hindernislauf, bei dem der Gewinner einen lebensverändernden Preis in Höhe von mehreren Millionen Dollar gewinnen sollte.");
		this.input.next();
		System.out.println("Der Preis: Das Leben derjenigen Teilnehmer, die es nicht bis zum Ende geschafft haben.");
		this.input.next();
		System.out.println("Dein Ziel als Spion ist es, sich als Teilnehmer in das Spiel zu infiltrieren, herauszufinden, wer dafür verantwortlich ist, und einen Plan zu erstellen, um diese Personen gefangen zu nehmen.");
		this.input.next();
		System.out.println("Das Spiel beginnt");
		this.input.next();
	}
}
