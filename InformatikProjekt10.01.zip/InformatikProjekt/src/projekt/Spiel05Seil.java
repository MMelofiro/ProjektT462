
package projekt;

public class Spiel05Seil {
    Input input = new Input();

    public Spiel05Seil() {
    }

    public void Seilschwingen(Player player) {
        player.recover();
        System.out.println("Seilschwingen");
        double hohe = Math.random() * 100.0 + 1.0;
        hohe *= 100.0;
        hohe = (double)Math.round(hohe);
        hohe /= 100.0;
        double g = 9.8;
        System.out.println("Sie werden von einem Fluss aufgehalten. Um fortzufahren, mussen Sie ein dortiges Seil nutzen, um auf die andere Seite zu schwingen.");
        System.out.println("Um die andere Seite zu erreichen, müssen Sie das Seil mit der richtigen Geschwindigkeit schwingen. Die Gravitationskonstante ist 9.8m/s^2. Die Höhe ist " + hohe + ". v = 2h/g =");
        double v = 2.0 * hohe / g;
        v *= 100.0;
        v = (double)Math.round(v);
        v /= 100.0;

        double vSpieler;
        for(vSpieler = this.input.scannerDouble("Geben Sie die erforderliche Geschwindigkeit zum Schwingen des Seils ein (in m/s): "); vSpieler < v; vSpieler = this.input.scannerDouble("Geben Sie die erforderliche Geschwindigkeit zum Schwingen des Seils ein (in m/s): ")) {
            System.out.println("Die Geschwindigkeit ist nicht ausreichend. Das Seil schwingt nicht weit genug. Du bist hinterfallen.");
            player.setHp(player.getHp() - 50);
            player.setSt(player.getSt() - 50);
            player.statusZeigen();
            if (player.getHp() <= 0 || player.getSt() < 0) {
                System.out.println("Sie haben alle Lebenspunkte verloren.");
                this.Seilschwingen(player);
                break;
            }

            System.out.println("Noch einmal versuchen.");
        }

        if (vSpieler >= v) {
            System.out.println("Herzlichen Glückwunsch! Sie haben die andere Seite erreicht.");
            if (player.getSt() > 15) {
               // player.setSt(15); // Problem
            }

            player.statusZeigen();
        }

    }
}
