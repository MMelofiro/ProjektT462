package projekt;

import java.util.Scanner;

public class Input {
	private Scanner scanner;

	public Input() {
		this.scanner = new Scanner(System.in);
	}

	public int scannerInt(String frage, int max) {
		int nummer = 0;
		System.out.println(frage);

		while(nummer < 1 || nummer > max) {
			if (this.scanner.hasNextDouble()) {
				nummer = this.scanner.nextInt();
			} else {
				System.out.println("Bitte, wählen Sie eine mögliche Antwort.");
				this.scanner.next();
			}
		}

		return nummer;
	}

	public double scannerDouble(String frage) {
		double nummer = 0.0;
		System.out.println(frage);

		while(!this.scanner.hasNextDouble()) {
			System.out.println("Bitte, wählen Sie eine mögliche Antwort.");
		}

		nummer = this.scanner.nextDouble();
		return nummer;
	}

	public void next() {
		System.out.println("\n...");
		this.scanner.nextLine();
	}

	public void fixNext() {
		this.scanner.nextLine();
	}

	public void closeScanner() {
		this.scanner.close();
	}
}
