package projekt;

public class Player {
	private int hp = 100;
	private int st = 100;
	private String nameSpieler;
	private String mitspieler;
	private boolean gerettet = false;
	private boolean schwer;
	private int hpSave;
	private int stSave;

	public Player() {
	}

	public int getHp() {
		return this.hp;
	}

	public int getSt() {
		return this.st;
	}

	public String getSpieler() {
		return this.nameSpieler;
	}

	public String getMitspieler() {
		return this.mitspieler;
	}

	public boolean getGerettet() {
		return this.gerettet;
	}

	public boolean getSchwer() {
		return this.schwer;
	}

	public void setHp(int health) {
		this.hp = health;
		if (this.hp <= 0) {
			System.out.println("Sie haben verloren. :(\nSie spielen ab dem letzten Kontrollpunkt.");
		}

	}

	public void setSt(int stamina) {
		this.st = stamina;
		if (this.st <= 0) {
			System.out.println("Sie haben verloren. :(\nSie spielen ab dem letzten Kontrollpunkt.");
		}

	}

	public void setGerettet(boolean gt) {
		this.gerettet = gt;
	}

	public void setSchwer(boolean schw) {
		this.schwer = schw;
	}

	public void charakter(int wahl) {
		if (wahl == 1) {
			this.nameSpieler = "Jason";
			this.setHp(75);
			this.setSt(125);
			this.mitspieler = "Allice";
		} else if (wahl == 2) {
			this.nameSpieler = "Allice";
			this.setHp(100);
			this.setSt(100);
			this.mitspieler = "Jason";
		}

	}

	public void schwierigkeit(int wahl) {
		if (wahl == 1) {
			this.setSchwer(false);
			System.out.println("Schwierigkeitsgrad auf Normal eingestellt.");
		} else if (wahl == 2) {
			this.setSchwer(true);
			System.out.println("Schwierigkeitsgrad auf Schwer eingestellt.");
		}

	}

	public void statusZeigen() {
		System.out.println("\nLebenspunkte: " + this.getHp());
		System.out.println("Stamina: " + this.getSt());
	}

	public void save() {
		this.hpSave = this.hp;
		this.stSave = this.st;
	}

	public void recover() {
		this.hp = this.hpSave;
		this.st = this.stSave;
	}
}
